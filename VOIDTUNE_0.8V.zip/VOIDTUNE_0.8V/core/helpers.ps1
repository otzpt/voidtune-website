# VOIDTUNE - core/helpers.ps1
# Copyright (C) 2026 @OTZPT - GPL v3

# G - find named element, never throws
function G($n) { try { $script:Win.FindName($n) } catch { $null } }

# UI - run action on UI dispatcher
function UI($a) { try { $script:Win.Dispatcher.Invoke($a) } catch {} }

# AddLog - append to log panel and write to file
function AddLog($msg, $col='#AAAAAA') {
    try {
        UI {
            $lo = G 'LogOut'; $ls = G 'LogScroll'
            if ($lo) { $lo.Text += "$msg`n" }
            if ($ls) { $ls.ScrollToBottom() }
        }
    } catch {}
    WL $msg
}

function SetProg($p)   { try { UI { $b = G 'LogProg';   if ($b) { $b.Value = $p } } } catch {} }
function SetStatus($s) { try { UI { $b = G 'LogStatus'; if ($b) { $b.Text  = $s } } } catch {} }

# ── RunC ──────────────────────────────────────────────────────────────────────
# Uses ProcessStartInfo so the full string (including &&) is passed to cmd.exe
# intact. PowerShell's & operator tokenises && and breaks chained commands.
function RunC($cmd) {
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName               = 'cmd.exe'
        $psi.Arguments              = "/c $cmd"
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError  = $true
        $psi.UseShellExecute        = $false
        $psi.CreateNoWindow         = $true
        $p   = [System.Diagnostics.Process]::Start($psi)
        $out = $p.StandardOutput.ReadToEnd() + $p.StandardError.ReadToEnd()
        $p.WaitForExit()
        return @{ OK = ($p.ExitCode -eq 0); Out = $out.Trim() }
    } catch { return @{ OK = $false; Out = $_.Exception.Message } }
}

# ── RunPS ─────────────────────────────────────────────────────────────────────
# Run a PowerShell scriptblock natively in this session.
# Use for cmdlets that don't exist in cmd (Disable-MMAgent, etc.)
function RunPS([scriptblock]$block) {
    try {
        $out = & $block 2>&1
        return @{ OK = $true; Out = ($out -join "`n") }
    } catch { return @{ OK = $false; Out = $_.Exception.Message } }
}

# ── Exec-Cmd ──────────────────────────────────────────────────────────────────
# Dispatcher: commands prefixed with "PS:" go to RunPS, everything else to RunC
function Exec-Cmd($cmd) {
    if ([string]::IsNullOrEmpty($cmd)) { return @{ OK = $true; Out = 'no-op' } }
    if ($cmd.StartsWith('PS:')) { return RunPS ([scriptblock]::Create($cmd.Substring(3).Trim())) }
    return RunC $cmd
}

# ── MakeBackup ────────────────────────────────────────────────────────────────
# Fixed: writes the .reg header exactly once, then appends only the key data
# from each per-key temp export (skipping the repeated header lines).
# Each key gets its own numbered temp file to avoid overwrites.
function MakeBackup($note) {
    try {
        $ts   = Get-Date -Format 'yyyyMMdd_HHmmss'
        $file = Join-Path $script:BACKUPS "backup_${ts}_${note}.reg"
        $keys = @(
            'HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl',
            'HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers',
            'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management',
            'HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel',
            'HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters',
            'HKLM\SYSTEM\CurrentControlSet\Services\AFD\Parameters',
            'HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters',
            'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile',
            'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games',
            'HKLM\SOFTWARE\Microsoft\Windows\Dwm',
            'HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile',
            'HKLM\SOFTWARE\Policies\Microsoft\Windows\Psched',
            'HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search',
            'HKLM\SOFTWARE\Policies\Microsoft\Power\PowerThrottling',
            'HKCU\System\GameConfigStore',
            'HKCU\Software\Microsoft\GameBar',
            'HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager',
            'HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects',
            'HKCU\Software\Microsoft\Windows\DWM',
            'HKCU\Control Panel\Desktop',
            'HKCU\Control Panel\Mouse'
        )

        # Write valid .reg header exactly once
        'Windows Registry Editor Version 5.00' | Set-Content $file -Encoding Unicode
        ''                                     | Add-Content  $file -Encoding Unicode

        $i = 0
        foreach ($k in $keys) {
            $i++
            $tmp = "$file.$i.tmp"
            $null = reg export $k $tmp /y 2>$null
            if (Test-Path $tmp) {
                $lines = Get-Content $tmp -Encoding Unicode -ErrorAction SilentlyContinue
                # lines[0] = "Windows Registry Editor Version 5.00", lines[1] = blank
                # Skip those two and append only the actual key data
                if ($lines -and $lines.Count -gt 2) {
                    $lines | Select-Object -Skip 2 | Add-Content $file -Encoding Unicode
                    ''                             | Add-Content $file -Encoding Unicode
                }
                Remove-Item $tmp -Force -ErrorAction SilentlyContinue
            }
        }
        return (Split-Path $file -Leaf)
    } catch { return 'backup-failed' }
}

# ── Tweak State Persistence ───────────────────────────────────────────────────
$script:STATE_FILE = Join-Path $script:ROOT 'voidtune_state.txt'

function Save-TweakState {
    try {
        $all     = $script:TWEAKS + $script:PRIVTWEAKS + $script:ARCH_TWEAKS
        $applied = @($all | Where-Object { $_.Applied } | ForEach-Object { $_.Id })
        Set-Content -Path $script:STATE_FILE -Value ($applied -join "`n") -Encoding UTF8
    } catch {}
}

function Load-TweakState {
    try {
        if (-not (Test-Path $script:STATE_FILE)) { return }
        $ids = @(Get-Content $script:STATE_FILE -Encoding UTF8 | Where-Object { $_ -ne '' })
        $all = $script:TWEAKS + $script:PRIVTWEAKS + $script:ARCH_TWEAKS
        foreach ($t in $all) {
            if ($ids -contains $t.Id) { $t.Applied = $true; $t.Sel = $true }
        }
        $script:applied = $ids.Count
        AddLog "Restored $($ids.Count) applied tweaks from last session." '#38BDF8'
    } catch {}
}
