# VOIDTUNE - ui/pages.ps1
# Copyright (C) 2026 @OTZPT - GPL v3
# Page refresh functions, ShowPage, FilterTweaks, DoApply

function RefreshDash {
    try {
        $os   = Get-CimInstance Win32_OperatingSystem  -EA SilentlyContinue
        $cpu  = Get-CimInstance Win32_Processor        -EA SilentlyContinue | Select-Object -First 1
        $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -EA SilentlyContinue
        $ci   = if ($cpu)  { [int]$cpu.LoadPercentage } else { 0 }
        $tot  = if ($os)   { [math]::Round($os.TotalVisibleMemorySize / 1MB, 1) } else { 1 }
        $used = if ($os)   { [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1MB, 1) } else { 0 }
        $dp   = if ($disk -and $disk.Size -gt 0) { [math]::Round(($disk.Size - $disk.FreeSpace) / $disk.Size * 100) } else { 50 }
        $rp   = if ($tot  -gt 0) { [math]::Round($used / $tot * 100) } else { 0 }
        $dOff = (Get-Service DiagTrack -EA SilentlyContinue).StartType -eq 'Disabled'
        $diagBonus = if ($dOff) { 90 } else { 30 }
        $score = [int](([math]::Max(0,100-$ci))*0.2 + ([math]::Max(0,100-$rp))*0.2 + ([math]::Max(0,100-$dp))*0.3 + $diagBonus*0.3)
        $cl = G 'CpuLbl';    if ($cl) { $cl.Text = "CPU  $ci%" }
        $cb = G 'CpuBar';    if ($cb) { $cb.Value = $ci }
        $rl = G 'RamLbl';    if ($rl) { $rl.Text = "RAM  ${used}GB" }
        $rb = G 'RamBar';    if ($rb) { $rb.Value = $rp }
        $dc = G 'DashCpu';   if ($dc) { $dc.Text = "$ci%" }
        $dr = G 'DashRam';   if ($dr) { $dr.Text = "${used}GB" }
        $hs = G 'HealthScore'; if ($hs) { $hs.Text = $score }
        $hlTxt = if ($score -ge 80) { "GOOD" } elseif ($score -ge 50) { "FAIR" } else { "NEEDS WORK" }
        $hl = G 'HealthLabel'; if ($hl) { $hl.Text = $hlTxt }
        if ($hs) {
            if     ($score -ge 80) { $hs.Foreground = [System.Windows.Media.Brushes]::LimeGreen }
            elseif ($score -ge 50) { $hs.Foreground = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Color]::FromRgb(245,158,11)) }
            else                   { $hs.Foreground = [System.Windows.Media.Brushes]::Crimson }
        }
        $procCount = (Get-Process -EA SilentlyContinue).Count
        $bn = @()
        if ($ci -gt 80)        { $bn += "HIGH CPU ($ci%) -- close background processes" }
        if ($dp -gt 90)        { $bn += "LOW DISK ($dp% full) -- clean C: drive" }
        if (-not $dOff)        { $bn += "TELEMETRY ACTIVE -- use Privacy tab to disable" }
        if ($procCount -gt 120){ $bn += "HIGH PROCESS COUNT ($procCount) -- use Process tab to kill bloat" }
        $bnTxt = if ($bn.Count -gt 0) { $bn -join "`n" } else { "No bottlenecks detected. System looks clean." }
        $bt  = G 'BnText';     if ($bt)  { $bt.Text  = $bnTxt }
        $da  = G 'DashApplied'; if ($da)  { $da.Text  = $script:applied }
        $db  = G 'DashBackups'; if ($db)  { $db.Text  = @(Get-ChildItem $script:BACKUPS -Filter '*.reg' -EA SilentlyContinue).Count }
        $dp2 = G 'DashProcs';   if ($dp2) { $dp2.Text = $procCount }
    } catch { AddLog "Dashboard error: $($_.Exception.Message)" '#E01818' }
}

function RefreshSvcs {
    try {
        foreach ($s in $script:svcOC) {
            $svc = Get-Service $s.Name -EA SilentlyContinue
            if ($svc) {
                $s.Status = $svc.Status.ToString().ToUpper()
                $s.SC     = if ($svc.Status -eq 'Running') { '#F59E0B' } else { '#22C55E' }
            } else {
                $s.Status = 'N/A'; $s.SC = '#3A3A3A'
            }
        }
    } catch { AddLog "Services error: $($_.Exception.Message)" '#E01818' }
}

function RefreshStartup {
    try {
        $items = @()
        $hives = @(
            'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run',
            'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
        )
        foreach ($hive in $hives) {
            $r = Get-ItemProperty $hive -EA SilentlyContinue
            if ($r) {
                $label = if ($hive -like 'HKCU*') { 'HKCU' } else { 'HKLM' }
                $r.PSObject.Properties | Where-Object { $_.Name -notlike 'PS*' } | ForEach-Object {
                    $items += [STI]@{ Name=$_.Name; Cmd=$_.Value; Hive=$label }
                }
            }
        }
        $col = New-Object 'System.Collections.ObjectModel.ObservableCollection[STI]'
        foreach ($i in $items) { $col.Add($i) }
        $sl = G 'StartupList'; if ($sl) { $sl.ItemsSource = $col }
    } catch { AddLog "Startup error: $($_.Exception.Message)" '#E01818' }
}

function RefreshDiag {
    try {
        $cpu   = Get-CimInstance Win32_Processor      -EA SilentlyContinue | Select-Object -First 1
        $gpu   = Get-DiscreteGpu
        $os    = Get-CimInstance Win32_OperatingSystem -EA SilentlyContinue
        $disk  = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'" -EA SilentlyContinue
        $board = Get-CimInstance Win32_BaseBoard -EA SilentlyContinue
        $cards = @()
        if ($cpu)  { $cards += [DC]@{Lbl='CPU';     Val=$cpu.Name.Trim();  Sub="$($cpu.NumberOfCores)c / $($cpu.NumberOfLogicalProcessors)t"} }
        if ($gpu)  {
            $allGpuStr = if ($script:HW.AllGpus.Count -gt 1) { 'Adapters: ' + ($script:HW.AllGpus -join ' | ') } else { '' }
            $cards += [DC]@{Lbl="GPU [$($script:HW.GpuVendor)]"; Val=$gpu.Name.Trim(); Sub="Driver $($gpu.DriverVersion)$(if($allGpuStr){' | '+$allGpuStr})"}
        }
        if ($os)   { $cards += [DC]@{Lbl='RAM';     Val="$([math]::Round($os.TotalVisibleMemorySize/1MB,1))GB"; Sub="$([math]::Round($os.FreePhysicalMemory/1MB,1))GB free"} }
        if ($disk) { $cards += [DC]@{Lbl='DISK C:'; Val="$([math]::Round($disk.Size/1GB,0))GB"; Sub="$([math]::Round($disk.FreeSpace/1GB,1))GB free"} }
        if ($os)   { $cards += [DC]@{Lbl='OS';      Val=$os.Caption.Trim(); Sub="Build $($os.BuildNumber)"} }
        if ($board){ $cards += [DC]@{Lbl='BOARD';   Val=$board.Product.Trim(); Sub=$board.Manufacturer.Trim()} }
        if ($os)   {
            $up = (Get-Date) - $os.LastBootUpTime
            $cards += [DC]@{Lbl='UPTIME'; Val=("{0}d {1}h {2}m" -f [int]$up.TotalDays,$up.Hours,$up.Minutes); Sub='Since last boot'}
        }
        $dl = G 'DiagList'
        if ($dl) {
            $col = New-Object 'System.Collections.ObjectModel.ObservableCollection[DC]'
            foreach ($c in $cards) { $col.Add($c) }
            $dl.ItemsSource = $col
        }
    } catch { AddLog "Diag error: $($_.Exception.Message)" '#E01818' }
}

function RefreshProc {
    try {
        $bloatNames = @(
            'OneDrive','Teams','MicrosoftTeams','SearchApp','SearchIndexer',
            'Cortana','WidgetService','widgets','GameBarPresenceWriter',
            'XboxGameBarWidgets','XboxGameBar','YourPhone','YourPhoneServer',
            'PhoneExperienceHost','WinStore.App','backgroundTaskHost',
            'RuntimeBroker','ShellExperienceHost','StartMenuExperienceHost',
            'SpeechRuntime','SpeechModelDownload','TabTip','TabTip32',
            'AdobeARM','AdobeUpdateService','acrotray','armsvc',
            'discord_updater','DiscordPTB','EpicGamesLauncher',
            'EADesktop','EABackgroundService','IGCCTray','IntelCpHDCPSvc'
        )
        $procs = Get-Process -EA SilentlyContinue |
            Where-Object { $_.WorkingSet64 -gt 512KB } |
            Sort-Object WorkingSet64 -Descending |
            Select-Object -First 60
        $col = New-Object 'System.Collections.ObjectModel.ObservableCollection[PI]'
        foreach ($p in $procs) {
            $ramMB   = [math]::Round($p.WorkingSet64 / 1MB, 0)
            $isBloat = $bloatNames -contains $p.ProcessName
            $cat     = if ($isBloat) { '⚠ BLOAT' } else { '' }
            $col.Add([PI]@{
                Name     = $p.ProcessName
                Pid      = $p.Id
                Ram      = "${ramMB} MB"
                Cpu      = ''
                Category = $cat
            })
        }
        $pl = G 'ProcList'; if ($pl) { $pl.ItemsSource = $col }
        $total = (Get-Process -EA SilentlyContinue).Count
        $pc = G 'ProcCount'; if ($pc) { $pc.Text = "TOTAL: $total processes" }
    } catch { AddLog "Process error: $($_.Exception.Message)" '#E01818' }
}

function Kill-Bloat {
    try {
        $bloat = @(
            'OneDrive','SearchApp','Cortana','WidgetService','widgets',
            'GameBarPresenceWriter','XboxGameBarWidgets','XboxGameBar',
            'YourPhone','YourPhoneServer','PhoneExperienceHost',
            'MicrosoftTeams','Teams','WinStore.App',
            'SpeechRuntime','SpeechModelDownload',
            'TabTip','TabTip32',
            'AdobeARM','armsvc','acrotray',
            'EABackgroundService','EADesktop',
            'IGCCTray',
            'SkypeApp','SkypeBackgroundHost',
            'HxOutlook','HxCalendarAppImm','HxAccounts',
            'Microsoft.Photos','Video.UI',
            'MixedRealityPortal','HolographicShell'
        )
        $protected = @('csrss','winlogon','lsass','smss','wininit','services',
                       'System','Idle','dwm','svchost','explorer','powershell',
                       'VOIDTUNE','cmd')
        $killed = 0
        foreach ($name in $bloat) {
            if ($protected -contains $name) { continue }
            $proc = Get-Process -Name $name -EA SilentlyContinue
            if ($proc) {
                Stop-Process -Name $name -Force -EA SilentlyContinue
                AddLog "  Killed: $name" '#22C55E'
                $killed++
            }
        }
        $total = (Get-Process -EA SilentlyContinue).Count
        AddLog "Bloat sweep done. Killed $killed processes. Total now: $total" '#22C55E'
        Start-Sleep -Milliseconds 500
        RefreshProc
    } catch { AddLog "Bloat kill error: $($_.Exception.Message)" '#E01818' }
}

function RefreshBackups {
    try {
        $files = Get-ChildItem $script:BACKUPS -Filter '*.reg' -EA SilentlyContinue |
                 Sort-Object LastWriteTime -Descending
        $col = New-Object 'System.Collections.ObjectModel.ObservableCollection[BKI]'
        foreach ($f in $files) {
            $col.Add([BKI]@{
                Name     = $f.Name
                FileName = $f.Name
                Date     = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm')
                Size     = "$([math]::Round($f.Length/1KB,1))KB"
            })
        }
        $bl = G 'BackupList'; if ($bl) { $bl.ItemsSource = $col }
    } catch { AddLog "Backup list error: $($_.Exception.Message)" '#E01818' }
}

function FilterTweaks {
    try {
        if (-not $script:TweakTabs) { return }
        $idx = $script:TweakTabs.SelectedIndex
        if ($idx -lt 0) { return }
        $cat = $script:catMap[$idx]
        if (-not $cat)  { return }
        $col = New-Object 'System.Collections.ObjectModel.ObservableCollection[TI]'
        foreach ($t in $script:TWEAKS)      { if ($t.Cat -eq $cat) { $col.Add($t) } }
        foreach ($t in $script:ARCH_TWEAKS) { if ($t.Cat -eq $cat) { $col.Add($t) } }
        $tl = G 'TweakList'; if ($tl) { $tl.ItemsSource = $col }
    } catch {}
}

# Install a single app - tries winget first, falls back to choco
function Install-App($app) {
    if ($script:HW.WingetOK) {
        try {
            $proc = Start-Process -FilePath "winget" `
                -ArgumentList "install --id $($app.Id) -e --accept-source-agreements --accept-package-agreements --scope machine" `
                -NoNewWindow -Wait -PassThru
            if ($proc.ExitCode -eq 0) { return @{ OK=$true; Via='winget' } }
        } catch {}
    }
    if ($script:HW.ChocoOK) {
        try {
            $chocoMap = @{
                'Google.Chrome'                   = 'googlechrome'
                'Mozilla.Firefox'                 = 'firefox'
                'Brave.Brave'                     = 'brave'
                'Opera.OperaGX'                   = 'opera-gx'
                'Discord.Discord'                 = 'discord'
                'Telegram.TelegramDesktop'        = 'telegram'
                'Valve.Steam'                     = 'steam'
                'TechPowerUp.GPU-Z'               = 'gpu-z'
                'CPUID.CPU-Z'                     = 'cpu-z'
                'REALiX.HWiNFO'                  = 'hwinfo'
                'MSI.MSIAfterburner'              = 'msiafterburner'
                'CrystalDewWorld.CrystalDiskInfo' = 'crystaldiskinfo'
                '7zip.7zip'                       = '7zip'
                'RARLab.WinRAR'                   = 'winrar'
                'VideoLAN.VLC'                    = 'vlc'
                'OBSProject.OBSStudio'            = 'obs-studio'
                'Microsoft.VisualStudioCode'      = 'vscode'
                'Notepad++.Notepad++'             = 'notepadplusplus'
                'SublimeHQ.SublimeText.4'         = 'sublimetext4'
                'Git.Git'                         = 'git'
                'GitHub.GitHubDesktop'            = 'github-desktop'
                'OpenJS.NodeJS'                   = 'nodejs'
                'Python.Python.3'                 = 'python'
                'Postman.Postman'                 = 'postman'
                'Neovim.Neovim'                   = 'neovim'
                'Microsoft.WindowsTerminal'       = 'microsoft-windows-terminal'
                'TimKosse.FileZilla.Client'       = 'filezilla'
                'WinSCP.WinSCP'                   = 'winscp'
                'Spotify.Spotify'                 = 'spotify'
                'GIMP.GIMP'                       = 'gimp'
                'Audacity.Audacity'               = 'audacity'
                'Malwarebytes.Malwarebytes'       = 'malwarebytes'
                'Bitwarden.Bitwarden'             = 'bitwarden'
                'Microsoft.PowerToys'             = 'powertoys'
                'voidtools.Everything'            = 'everything'
                'HandBrake.HandBrake'             = 'handbrake'
                'Rufus.Rufus'                     = 'rufus'
                'ShareX.ShareX'                   = 'sharex'
                'AutoHotkey.AutoHotkey'           = 'autohotkey'
            }
            $chocoId = $chocoMap[$app.Id]
            if ($chocoId) {
                $proc = Start-Process -FilePath "choco" `
                    -ArgumentList "install $chocoId -y" `
                    -NoNewWindow -Wait -PassThru
                if ($proc.ExitCode -eq 0) { return @{ OK=$true; Via='choco' } }
            }
        } catch {}
    }
    return @{ OK=$false; Via='none' }
}

function DoApply {
    try {
        $sel   = @($script:TWEAKS + $script:PRIVTWEAKS + $script:ARCH_TWEAKS | Where-Object { $_.Sel })
        $apps  = @($script:APPS_DATA | Where-Object { $_.Sel })
        $total = $sel.Count + $apps.Count
        if ($total -eq 0) {
            UI { [System.Windows.MessageBox]::Show("Nothing selected.", "VOIDTUNE") }
            return
        }

        # Warn about EXTREME tweaks
        $extremeSel = @($sel | Where-Object { $_.Badge -eq 'EXTREME' })
        if ($extremeSel.Count -gt 0) {
            $extremeNames = ($extremeSel | ForEach-Object { $_.Name }) -join "`n  - "
            $warn  = "You have $($extremeSel.Count) EXTREME tweak(s) selected:`n`n  - $extremeNames`n`nThese are aggressive settings that may cause instability on some hardware."
            if ($sel | Where-Object { $_.Id -eq 'gpu5'  }) { $warn += "`n`n[!] DISABLE MPO can cause flickering or black screens on some GPU/driver combos. Revertible." }
            if ($sel | Where-Object { $_.Id -eq 'gpu12' }) { $warn += "`n`n[!] NO GPU PREEMPT can cause TDR crashes under heavy GPU load. Revertible." }
            if ($sel | Where-Object { $_.Id -eq 'gpu13' }) { $warn += "`n`n[!] MAX GPU CLOCKS raises idle power draw significantly on desktop GPUs." }
            if ($sel | Where-Object { $_.Id -eq 'lat3'  }) { $warn += "`n`n[!] IRQ PRIORITY can cause device conflicts on certain hardware configurations." }
            $warn += "`n`nA registry backup will be created. Continue?"
            $confirm = $null
            UI { $confirm = [System.Windows.MessageBox]::Show($warn, "VOIDTUNE - EXTREME Tweaks", [System.Windows.MessageBoxButton]::YesNo, [System.Windows.MessageBoxImage]::Warning) }
            if ($confirm -ne 'Yes') { return }
        }

        if ($apps.Count -gt 0 -and -not $script:HW.WingetOK -and -not $script:HW.ChocoOK) {
            AddLog "WARNING: Neither winget nor Chocolatey found. App installs will be skipped." '#F59E0B'
        }

        SetProg 0; SetStatus 'BACKING UP...'
        $bk = MakeBackup 'apply'
        AddLog "BACKUP: $bk" '#22C55E'
        AddLog "Starting $total operations..." '#AAAAAA'

        $i = 0; $ok = 0; $fail = 0
        foreach ($tw in $sel) {
            $i++
            SetProg ([math]::Round($i / $total * 100))
            SetStatus $tw.Name
            AddLog "[$i/$total] $($tw.Name)" '#AAAAAA'
            $r = Exec-Cmd $tw.Cmd
            if ($r.OK) {
                AddLog "  OK" '#22C55E'
                $ok++
                # Only increment counter if not already applied (avoid double-counting)
                if (-not $tw.Applied) { $script:applied++ }
                $tw.Applied = $true
            } else {
                AddLog "  FAILED: $($r.Out.Split("`n")[0])" '#E01818'
                $fail++
            }
        }

        foreach ($app in $apps) {
            $i++
            SetProg ([math]::Round($i / $total * 100))
            SetStatus "Installing $($app.Name)"
            AddLog "[$i/$total] INSTALL $($app.Name)" '#AAAAAA'
            $result = Install-App $app
            if ($result.OK) { AddLog "  OK [via $($result.Via)]" '#22C55E'; $ok++ }
            else             { AddLog "  FAILED: winget and choco both unavailable or package not found" '#E01818'; $fail++ }
        }

        SetProg 100; SetStatus 'DONE'
        UI {
            $lc = G 'LogCount';    if ($lc) { $lc.Text  = "$ok applied / $fail failed" }
            $da = G 'DashApplied'; if ($da) { $da.Text  = $script:applied }
        }
        AddLog "DONE: $ok applied, $fail failed. Restart recommended." '#22C55E'
        Save-TweakState
        UI { FilterTweaks }
    } catch { AddLog "Apply error: $($_.Exception.Message)" '#E01818' }
}

function RefreshDrivers {
    try {
        $filter    = G 'DrFilter'
        $filterVal = if ($filter) { $filter.Text.Trim().ToLower() } else { '' }
        $drivers   = Get-DriverList
        if ($filterVal) {
            $drivers = $drivers | Where-Object {
                $_.Name.ToLower().Contains($filterVal) -or
                $_.Cat.ToLower().Contains($filterVal)  -or
                $_.Mfg.ToLower().Contains($filterVal)
            }
        }
        $col = New-Object 'System.Collections.ObjectModel.ObservableCollection[DRI]'
        foreach ($d in $drivers) {
            $col.Add([DRI]@{ Name=$d.Name; Version=$d.Version; Date=$d.Date; Mfg=$d.Mfg; Cat=$d.Cat })
        }
        $dl = G 'DriverList';  if ($dl) { $dl.ItemsSource = $col }
        $dc = G 'DriverCount'; if ($dc) { $dc.Text = "$($col.Count) drivers" }
    } catch { AddLog "Driver refresh error: $($_.Exception.Message)" '#E01818' }
}

function RefreshGpuHealth {
    try {
        $data  = Get-GpuHealthData
        $items = @(
            @{ K='GPU';         V=$data.Name      },
            @{ K='Vendor';      V=$data.Vendor    },
            @{ K='Driver';      V=$data.DriverVer },
            @{ K='Driver Date'; V=$data.DriverDate},
            @{ K='VRAM Total';  V=$data.VramTotal },
            @{ K='VRAM Free';   V=$data.VramFree  },
            @{ K='GPU Usage';   V="$($data.Usage)%"},
            @{ K='Temperature'; V=$data.TempC     },
            @{ K='Core Clock';  V=$data.CoreClock },
            @{ K='Mem Clock';   V=$data.MemClock  },
            @{ K='Fan Speed';   V=$data.FanSpeed  },
            @{ K='Power Draw';  V=$data.PowerDraw }
        )
        foreach ($item in $items) {
            $el = G "GH_$($item.K -replace ' ','_')"
            if ($el) { $el.Text = $item.V }
        }
        $ag = G 'GH_AllGpus'; if ($ag) { $ag.Text = ($data.AllGpus -join '  |  ') }
        $ub = G 'GH_UsageBar'; if ($ub) { $ub.Value = $data.Usage }
    } catch { AddLog "GPU health error: $($_.Exception.Message)" '#E01818' }
}

function RefreshLatencyPage {
    $lr = G 'LatResults'; if ($lr) { $lr.Text = 'Click RUN LATENCY CHECK to begin...' }
    $ls = G 'LatScore';   if ($ls) { $ls.Text = '--' }
}

function Run-LatencyCheck {
    try {
        $lr    = G 'LatResults'
        $score = 100
        $issues = @()

        $update = {
            param($txt)
            UI {
                if ($lr) { $lr.Text += "$txt`n" }
                $ls2 = G 'LatScroll'; if ($ls2) { $ls2.ScrollToBottom() }
            }
        }

        UI { if ($lr) { $lr.Text = '' } }
        & $update "VOIDTUNE SYSTEM LATENCY CHECKER v0.8"
        & $update "=========================================`n"

        # ── 1. Timer Resolution ──────────────────────────────────────────────
        & $update "[ 1/6 ] SYSTEM TIMER RESOLUTION"
        $timer = Get-SystemTimerResolution
        & $update "  Current : $($timer.Current) ms"
        & $update "  Min     : $($timer.Min) ms"
        & $update "  Max     : $($timer.Max) ms"
        if ($timer.Current -le 0.6) {
            & $update "  Rating  : EXCELLENT -- timer already at max precision`n"
        } elseif ($timer.Current -le 1.1) {
            & $update "  Rating  : GOOD`n"
        } else {
            & $update "  Rating  : NEEDS FIX -- apply TIMER RESOLUTION tweak in Tweaks > CPU`n"
            $score -= 20; $issues += "Timer resolution: $($timer.Current)ms (apply TIMER RESOLUTION tweak)"
        }

        # ── 2. DPC Latency Heuristic ─────────────────────────────────────────
        & $update "[ 2/6 ] DPC LATENCY HEURISTIC"
        $dpc = Get-DpcLatencyHeuristic
        & $update "  Score   : $($dpc.Score)/100"
        if ($dpc.Issues.Count -eq 0) {
            & $update "  Status  : No known DPC issues detected`n"
        } else {
            foreach ($iss in $dpc.Issues) { & $update "  ISSUE   : $iss" }
            & $update ""
            $score -= [math]::Min(25, $dpc.Issues.Count * 8)
        }

        # ── 3. Disk I/O Latency ──────────────────────────────────────────────
        & $update "[ 3/6 ] DISK I/O LATENCY (4KB random reads, C:)"
        $disk = Measure-DiskLatency
        if ($disk.OK) {
            & $update "  Avg     : $($disk.AvgMs) ms"
            & $update "  Max     : $($disk.MaxMs) ms"
            $rating = if ($disk.AvgMs -lt 0.1)  { 'EXCELLENT (NVMe)' }
                      elseif ($disk.AvgMs -lt 0.5)  { 'VERY GOOD (fast SSD)' }
                      elseif ($disk.AvgMs -lt 2.0)  { 'GOOD (SSD)' }
                      elseif ($disk.AvgMs -lt 10.0) { 'OK (SATA SSD)' }
                      else                           { 'SLOW (HDD or thermal throttle)' }
            & $update "  Rating  : $rating`n"
            if ($disk.AvgMs -gt 5.0) { $score -= 10; $issues += "Disk latency high: $($disk.AvgMs)ms avg" }
        } else {
            & $update "  Status  : Measurement failed`n"
        }

        # ── 4. Memory Latency ────────────────────────────────────────────────
        & $update "[ 4/6 ] MEMORY LATENCY (sequential, 64-byte stride)"
        $mem = Measure-MemoryLatency
        if ($mem.OK) {
            & $update "  Access  : $($mem.NsPerAccess) ns/access"
            $rating = if ($mem.NsPerAccess -lt 3)  { 'EXCELLENT (DDR5/fast DDR4)' }
                      elseif ($mem.NsPerAccess -lt 6)  { 'GOOD (DDR4)' }
                      elseif ($mem.NsPerAccess -lt 12) { 'OK (DDR4 slower)' }
                      else                             { 'SLOW (check XMP/EXPO)' }
            & $update "  Rating  : $rating`n"
            if ($mem.NsPerAccess -gt 10) { $score -= 10; $issues += "Memory latency high: $($mem.NsPerAccess)ns (enable XMP/EXPO in BIOS)" }
        } else {
            & $update "  Status  : Measurement failed`n"
        }

        # ── 5. Network Ping ──────────────────────────────────────────────────
        & $update "[ 5/6 ] NETWORK LATENCY (ping)"
        $netHosts   = @('8.8.8.8','1.1.1.1','208.67.222.222')
        $netResults = Measure-NetworkLatency $netHosts
        foreach ($r in $netResults) {
            if ($r.OK) {
                & $update "  $($r.Host.PadRight(20)) Avg: $($r.AvgMs)ms  Min: $($r.MinMs)ms  Max: $($r.MaxMs)ms  Jitter: $($r.Jitter)ms"
            } else {
                & $update "  $($r.Host.PadRight(20)) TIMEOUT"
            }
        }
        $bestPing = ($netResults | Where-Object { $_.OK } | Sort-Object AvgMs | Select-Object -First 1)
        if ($bestPing) {
            $netRating = if ($bestPing.AvgMs -lt 10) { 'EXCELLENT' }
                         elseif ($bestPing.AvgMs -lt 30) { 'GOOD' }
                         elseif ($bestPing.AvgMs -lt 80) { 'OK' }
                         else                            { 'HIGH -- check ISP / VPN' }
            & $update "  Best    : $($bestPing.AvgMs)ms -- $netRating`n"
            if ($bestPing.AvgMs -gt 80) { $score -= 10 }
            if ($bestPing.Jitter -gt 20) { $score -= 5; $issues += "High ping jitter: $($bestPing.Jitter)ms (check network adapter tweaks)" }
        } else {
            & $update "  Status  : No hosts reachable (offline?)`n"
        }

        # ── 6. DNS Resolution ────────────────────────────────────────────────
        & $update "[ 6/6 ] DNS RESOLUTION LATENCY"
        $dnsHosts   = @('google.com','cloudflare.com','github.com','youtube.com')
        $dnsResults = Measure-DnsLatency $dnsHosts
        foreach ($r in $dnsResults) {
            & $update "  $($r.Host.PadRight(22)) $($r.AvgMs)ms"
        }
        $avgDns   = [math]::Round(($dnsResults | Measure-Object AvgMs -Average).Average, 1)
        $dnsRating = if ($avgDns -lt 10) { 'EXCELLENT' }
                     elseif ($avgDns -lt 30) { 'GOOD' }
                     elseif ($avgDns -lt 80) { 'OK' }
                     else                    { 'SLOW -- try Flush DNS tweak or change DNS server' }
        & $update "  Avg     : ${avgDns}ms -- $dnsRating`n"
        if ($avgDns -gt 80) { $score -= 5; $issues += "DNS slow: ${avgDns}ms (flush DNS or use 1.1.1.1)" }

        # ── SUMMARY ──────────────────────────────────────────────────────────
        $score = [math]::Max(0, [math]::Min(100, $score))
        $scoreLabel = if ($score -ge 85) { 'EXCELLENT' } elseif ($score -ge 65) { 'GOOD' } elseif ($score -ge 40) { 'FAIR' } else { 'NEEDS WORK' }
        & $update "========================================="
        & $update "LATENCY SCORE: $score/100 -- $scoreLabel"
        & $update "========================================="
        if ($issues.Count -gt 0) {
            & $update "`nRECOMMENDATIONS:"
            foreach ($iss in $issues) { & $update "  >> $iss" }
        } else {
            & $update "`nNo major latency issues detected."
        }
        & $update "`nCompleted: $(Get-Date -f 'HH:mm:ss')"

        UI { $ls = G 'LatScore'; if ($ls) { $ls.Text = "$score" } }
        AddLog "Latency check complete. Score: $score/100 ($scoreLabel)" '#38BDF8'
    } catch { AddLog "Latency check error: $($_.Exception.Message)" '#E01818' }
}

function ShowPage($name) {
    try {
        foreach ($p in $script:allPages) {
            $pg = G $p; if ($pg) { $pg.Visibility = 'Collapsed' }
        }
        $show = G $name; if ($show) { $show.Visibility = 'Visible' }

        $btnMap = @{
            PgDash='BtnDash'; PgTweaks='BtnTweaks'; PgApps='BtnApps'; PgServices='BtnServices'
            PgStartup='BtnStartup'; PgPrivacy='BtnPrivacy'; PgDiag='BtnDiag'; PgBench='BtnBench'
            PgSafety='BtnSafety'; PgScript='BtnScript'; PgProc='BtnProc'; PgPersonalize='BtnPersonalize'
            PgDrivers='BtnDrivers'; PgGpuHealth='BtnGpuHealth'; PgLatency='BtnLatency'
        }

        # Use Style switching — avoids mutating frozen shared WPF brushes
        $activeStyle   = try { $script:Win.Resources['SbBtnActive'] } catch { $null }
        $inactiveStyle = try { $script:Win.Resources['SbBtn']       } catch { $null }

        foreach ($kv in $btnMap.GetEnumerator()) {
            $b = G $kv.Value; if (-not $b) { continue }
            if ($kv.Key -eq $name) {
                if ($activeStyle)   { $b.Style = $activeStyle }
            } else {
                if ($inactiveStyle) { $b.Style = $inactiveStyle }
            }
        }

        # Lazy refresh — only runs WMI/IO when tab is actually opened
        switch ($name) {
            'PgDash'        { RefreshDash }
            'PgServices'    { RefreshSvcs }
            'PgStartup'     { RefreshStartup }
            'PgDiag'        { RefreshDiag }
            'PgSafety'      { RefreshBackups }
            'PgPersonalize' { RefreshPersonalize }
            'PgDrivers'     { RefreshDrivers }
            'PgGpuHealth'   { RefreshGpuHealth }
            'PgLatency'     { RefreshLatencyPage }
        }
    } catch { AddLog "Navigation error: $($_.Exception.Message)" '#E01818' }
}
